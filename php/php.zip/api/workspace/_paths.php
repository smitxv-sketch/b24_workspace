<?php
/**
 * SSOT для путей workspace API.
 * Меняем базовые директории только здесь.
 */

// Базовые веб-пути проекта.
const WS_LOCAL_ROOT          = '/local';
const WS_BPROC_ROOT          = WS_LOCAL_ROOT . '/bproc';
const WS_BPROC_LIB_ROOT      = WS_BPROC_ROOT . '/lib';
const WS_BPROC_PROCESSES_DIR = WS_BPROC_ROOT . '/processes';
const WS_BPROC_ROLES_DIR     = WS_BPROC_ROOT . '/workspace_roles';

/**
 * Преобразует веб-путь в абсолютный путь на файловой системе.
 */
function wsDocPath(string $webPath): string {
    return rtrim($_SERVER['DOCUMENT_ROOT'] ?? '', '/') . $webPath;
}

